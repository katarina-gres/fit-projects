<?php

$x = $x;
