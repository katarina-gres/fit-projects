<?php
function a() {
}

$x=a();
if($x !== null) {
	$x=put_string("CHYBA porovnavani NULL\n");
}
