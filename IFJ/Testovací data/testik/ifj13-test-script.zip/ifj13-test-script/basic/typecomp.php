<?php

if(true < 7) {
}
else{
	$x=put_string("CHYBA, TYPOVA KOMPATABILITA");
}
