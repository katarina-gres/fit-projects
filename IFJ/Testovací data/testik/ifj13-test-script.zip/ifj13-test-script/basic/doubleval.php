<?php

// prvni spatny znak je e -> musi vypsat nulu a ne hodit chybu

$c = doubleval("e123");
$x=put_string($c);


