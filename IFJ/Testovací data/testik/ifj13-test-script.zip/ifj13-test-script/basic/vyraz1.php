<?php 

if (""){
  $x=put_string("CHYBA V PROGRAMU\n");
} else {}
