<?php

function x() {
	$prom = 5;
}

if(x() !== null) {
	$x=put_string("chyba");
}

return 42;
