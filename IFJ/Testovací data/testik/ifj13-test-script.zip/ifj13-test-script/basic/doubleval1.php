<?php


$x=doubleval("          3.1e");


