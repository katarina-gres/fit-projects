<?php 

$x = " \ \w \/ \* \~ \xw \XYZ";
$x= put_string($x,"\n");
$x = " \x\x64 \XYZ";
$x= put_string($x,"\n");
$x = "\xAf\xaF\xAF";
$x= put_string($x,"\n");
