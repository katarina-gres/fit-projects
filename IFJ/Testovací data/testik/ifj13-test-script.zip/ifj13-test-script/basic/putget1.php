<?php

$x = get_string();
$x= put_string($x);
