<?php

function @ aaa() {}
