<?php

$x = put_string($x);
