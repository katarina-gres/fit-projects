<?php

if(true) {
$a = 2;
}
$x=put_string($a);
