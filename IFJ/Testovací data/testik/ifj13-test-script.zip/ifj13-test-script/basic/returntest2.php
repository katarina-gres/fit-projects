<?php

function asx($a=true) {return $a;}
$x=asx();
$x=put_string($x);
