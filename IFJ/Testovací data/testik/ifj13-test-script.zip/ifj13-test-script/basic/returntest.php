<?php

function asx() {return "Hello world!\n";}
$x=asx();
$x=put_string($x);
