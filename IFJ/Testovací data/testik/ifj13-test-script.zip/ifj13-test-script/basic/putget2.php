<?php

$str = get_string();

while($str !== ""){
  $x=put_string($str);
  $str= get_string();
}
