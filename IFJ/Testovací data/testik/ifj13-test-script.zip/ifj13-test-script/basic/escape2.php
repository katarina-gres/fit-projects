<?php $a = 1    ;
$b=2;  
$c  =  3;

// Program 7: Zajimavy zapis operaci =]


$x = put_string($a, " \x28 ", $b, " ", $c, "\n");

/** Vypujcene z testu od Karla Breziny */
