<?php

function aaa(){

  function xxx(){

  }

}
