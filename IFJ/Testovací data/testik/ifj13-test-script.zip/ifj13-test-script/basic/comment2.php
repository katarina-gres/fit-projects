<?php 


function cmpstr() { // a je mensi nez b

} 


function xxx() { 
$x = 5;//koment

} 

// koment
$x=5;


