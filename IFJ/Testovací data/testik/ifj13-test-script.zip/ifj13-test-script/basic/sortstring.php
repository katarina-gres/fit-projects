<?php
$a="Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit.";
$b="O tempora, o mores!";
$c="Stultitia excusationem non habet.";
$d="Legum servi sumus ut liberi esse possimus.";
$e="Amicus est tamquam alter idem.";
$f="Dum spiro, spero.";
$g="Ut corpora nostra sine mente, sic civitas sine lege.";
$h="Silent enim leges inter arma.";
$i="Quo usque tandem abutere Catilina patientia nostra! Quam diu furor iste tuus nos eludet!";
$j="Res publica est consensus iuris et communio utilitatis.";
$k="Appetitus rationi pareat.";
$l="Nemo enim fere saltat sobrius, nisi forte insanit.";
$m="Quidem concessum est rhetoribus ementiri in historiis ut aliquid dicere possint argutius.";
$n="Salus populi est suprema lex.";
$o="Suum cuique.";
$p="Ubi bene, ibi patria!";
$q="Vi et armis.";
$r="Vi victa vis.";
$s="Praeteritum tempus numquam revertitur.";

$str=$a.$b.$c.$d.$e.$f.$g.$h.$i.$j.$k.$l.$m.$m.$o.$p.$q.$r.$s;

$sort_string=sort_string($str);
$x=put_string($sort_string);
