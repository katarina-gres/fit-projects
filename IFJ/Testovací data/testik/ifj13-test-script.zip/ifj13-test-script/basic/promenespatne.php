<?php

if(null) {
	$ = 1;}
else {
	$1= 5;
}
