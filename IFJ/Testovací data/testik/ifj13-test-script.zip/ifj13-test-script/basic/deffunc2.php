<?php

if (true){

  function xxx(){

  }

} else {}
