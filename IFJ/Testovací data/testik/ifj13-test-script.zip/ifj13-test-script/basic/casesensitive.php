<?php

$a = 5;
$b = $a * Fun(5);

function fun($a) {
	return 5;}
