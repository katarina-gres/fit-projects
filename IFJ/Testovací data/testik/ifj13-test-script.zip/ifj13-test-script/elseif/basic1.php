<?php

if(false) {
	$_=put_string("chyba\n");
}
elseif(false){
	$_=put_string("chyba\n");
}
else {
	$_=put_string("o");
}

if(5 + 5 * 5) {
	$_=put_string("o");
}
else {
	$_=put_string("chyba\n");
}

if(true){
	$_=put_string("o");
}

if(true){
	$_=put_string("o");
if(true){
	$_=put_string("o");
if(true){
	$_=put_string("o");
if(true){
	$_=put_string("o");
if(true){
	$_=put_string("o");
if(true){
	$_=put_string("o");
}else {
	$_=put_string("chyba\n");
}}}else {
	$_=put_string("chyba\n");
}}else {
	$_=put_string("chyba\n");
}}else {
	$_=put_string("chyba\n");
}}else {
	$_=put_string("chyba\n");
}
