<?php
$x=put_string(strlen(intval(doubleval("  3.14e5")))-strlen(0000123)*strlen(42));
