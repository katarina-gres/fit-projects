<?php

/*
 * README:
 * tento test nam zacyklil cely interpret
 * takze pokus se vam cykli, tak jej zruste :D
 * */

function ahoj() {}

$a = 1ahoj();
