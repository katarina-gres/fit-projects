<?php

if(5 <= 8 and 1 !== 3  and true && (3*3 === 9 or "string" === "strong") && 5 * 5 + 2 or !(5.41348) && 1e56 and (true or false) or !false) {
	$x=put_string("ok");
}
else {
	$x = put_string("chyba");
}
