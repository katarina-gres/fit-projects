<?php

if( true and true || true and false ){
  $x=put_string("chyba: and  ma vyssi prioritu nez || ale nemel by");
}
