<?php

function aaa($a,$abcd=5,$xyz = 5.) {}
$x=aaa(1,2);
