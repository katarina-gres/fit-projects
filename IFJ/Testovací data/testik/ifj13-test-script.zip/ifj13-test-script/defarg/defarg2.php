<?php


$x=       xyz("\n",7);
$asdadadadadad=       xyz();

$qeqrqrqrqrq= xyz("prvni","druhy","treti","ctvrty");



function xyz ($a = "jedna " , $b= "dva " , $c ="Lorem ipsum dolor sit a met\n" ) {
  $x=put_string($a,$b,$c);
}




