<?php

function aaa($a,$abcd=5,$xyz) {}
$x=aaa(1,2);
