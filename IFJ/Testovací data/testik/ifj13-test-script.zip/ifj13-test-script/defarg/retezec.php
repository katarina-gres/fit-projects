<?php

function asx($a, $b, $c = "vysledek") {return $c;}
$x=put_string(asx(1,2));
